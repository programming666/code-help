#include "downloadtask.h"
#include <QDir>
#include <QNetworkReply>
#include <QFile>
#include <QMessageBox>
#include <QDebug>

DownloadTask::DownloadTask(const QUrl &url, const QString &saveDir, const QString &fileName,
                           qint64 startByte, qint64 endByte, QObject *parent)
    : QThread(parent), m_url(url), 
    m_savePath(QDir(saveDir).filePath(fileName)),
    m_startByte(startByte), m_endByte(endByte)
{
}

void DownloadTask::run()
{
    QNetworkRequest request(m_url);
    request.setRawHeader("Range", QString("bytes=%1-%2").arg(m_startByte).arg(m_endByte).toUtf8());

    QNetworkAccessManager* threadManager = new QNetworkAccessManager();
    m_reply = threadManager->get(request);
    connect(m_reply, &QNetworkReply::readyRead, this, &DownloadTask::onReadyRead);
    connect(m_reply, &QNetworkReply::finished, this, &DownloadTask::onFinished);
    exec();
}

void DownloadTask::onReadyRead()
{
    if (!m_reply) return;

    QWriteLocker locker(&m_fileLock);
    QFile file(m_savePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append)) {
        QMessageBox::critical(nullptr,tr("警告"),tr("错误：")+file.errorString());
        return;
    }

    QByteArray data = m_reply->readAll();
    qint64 bytesToWrite = data.size();
    if (bytesToWrite > 0) {
        file.seek(m_startByte + m_downloadedBytes);
        qint64 written = file.write(data);
        
        if (written != -1) {
            m_downloadedBytes += written;
            qDebug() << "[下载进度] 线程" << QThread::currentThreadId() 
                     << "已写入:" << written << "字节"
                     << "总进度:" << m_downloadedBytes << "/" << (m_endByte - m_startByte + 1);
            emit progress(written, m_endByte - m_startByte + 1);
        } else {
            qDebug() << "[写入失败]" << file.errorString();
            emit progress(0, 0);
        }
    }
}

void DownloadTask::onFinished()
{
    if (m_reply->error() != QNetworkReply::NoError) {
        QMessageBox::critical(nullptr,tr("错误"),tr("错误信息：")+m_reply->errorString());
    }
    m_reply->deleteLater();
    emit taskFinished();
}
