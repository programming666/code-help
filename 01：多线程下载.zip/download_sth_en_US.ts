<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DownloadTask</name>
    <message>
        <location filename="downloadtask.cpp" line="31"/>
        <source>警告</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="downloadtask.cpp" line="31"/>
        <source>错误：</source>
        <translation>Error:</translation>
    </message>
    <message>
        <location filename="downloadtask.cpp" line="47"/>
        <source>错误</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="downloadtask.cpp" line="47"/>
        <source>错误信息：</source>
        <translation>Error message:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>多线程下载器</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="31"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:36pt;&quot;&gt;多线程下载器&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:36pt;&quot;&gt;Multithreaded downloader:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="54"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;下载URL：&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:20pt;&quot;&gt;Download URL：&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="67"/>
        <source>开始下载</source>
        <translation>Start download</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="93"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:22pt;&quot;&gt;下载线程数：&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:22pt;&quot;&gt;Number of download threads:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="27"/>
        <source>错误</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="27"/>
        <source>下载链接为空</source>
        <translation>The download link is empty.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="31"/>
        <source>保存文件</source>
        <translation>Save file name</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="38"/>
        <location filename="mainwindow.cpp" line="44"/>
        <source>警告</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="38"/>
        <source>无法获取文件大小！</source>
        <translation>Cannot gets the file size!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="44"/>
        <source>HEAD请求失败：</source>
        <translation>HEAD request failed:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>完成</source>
        <translation>complete</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>文件下载完成！</source>
        <translation>File download compelete</translation>
    </message>
</context>
</TS>
