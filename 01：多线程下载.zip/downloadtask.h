#ifndef DOWNLOADTASK_H
#define DOWNLOADTASK_H

#include <QNetworkAccessManager>
#include <QThread>
#include <QNetworkReply>
#include <QFile>
#include <QReadWriteLock>

class DownloadTask : public QThread
{
    Q_OBJECT

public:
    explicit DownloadTask(const QUrl &url, const QString &saveDir, const QString &fileName,
                          qint64 startByte, qint64 endByte,
                          QObject *parent = nullptr);

signals:
    void progress(qint64 bytesReceived, qint64 bytesTotal);
    void taskFinished();

protected:
    void run() override;

private slots:
    void onReadyRead();
    void onFinished();

private:
    QUrl m_url;
    QString m_savePath;
    qint64 m_startByte;
    qint64 m_endByte;
    QNetworkAccessManager manager;
    QFile file;
    QReadWriteLock m_fileLock;
    qint64 m_downloadedBytes = 0;
    QNetworkReply* m_reply;
};

#endif // DOWNLOADTASK_H
