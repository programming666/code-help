#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QFileDialog>
#include <QMessageBox>
#include <QDir>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , manager(new QNetworkAccessManager(this))
{
    ui->setupUi(this);
    connect(ui->start, &QPushButton::clicked, this, &MainWindow::onStartDownloadClicked);
    connect(ui->choose, &QPushButton::clicked, this, &MainWindow::chooseSaveDir);
    setWindowIcon(QIcon(":/icon/icon.png"));
}

MainWindow::~MainWindow()
{
    for (DownloadTask* task : activeTasks) {
        task->requestInterruption();
        task->wait();
        delete task;
    }
    delete ui;
}

void MainWindow::onStartDownloadClicked()
{
    QMessageBox::information(this,"开始下载","开始下载");
    ui->progress->setValue(0);
    QString urlstr = ui->url->text();
    if(urlstr.isEmpty()) {
        QMessageBox::critical(this, tr("错误"), tr("下载链接为空"));
        return;
    }
    
    if (!urlstr.contains("://")) {
        urlstr.prepend("http://");
    }
    
    downloadUrl = QUrl::fromUserInput(urlstr);
    if (!downloadUrl.isValid()) {
        QMessageBox::critical(this, tr("错误"), tr("无效的URL格式"));
        return;
    }
    
    QString saveDir = ui->savepath->text();
    if(saveDir.isEmpty()) {
        QMessageBox::critical(this, tr("错误"), tr("请先选择保存目录"));
        return;
    }
    
    QFileInfo fileInfo(downloadUrl.path());
    QString fileName = fileInfo.fileName().isEmpty() ? "download" : fileInfo.fileName();
    savePath = QDir(saveDir).filePath(fileName);
    
    QNetworkRequest headRequest(downloadUrl);
    QNetworkReply* headReply = manager->get(headRequest);
    connect(headReply, &QNetworkReply::finished, [this, headReply]() {
        if (headReply->error() == QNetworkReply::NoError) {
            totalBytes = headReply->header(QNetworkRequest::ContentLengthHeader).toLongLong();
            if(totalBytes > 0) {
                startMultiThreadDownload(totalBytes);
            } else {
                QMessageBox::critical(this, tr("错误"), tr("无法获取文件大小"));
            }
        } else {
            QMessageBox::critical(this, tr("错误"), headReply->errorString());
        }
        headReply->deleteLater();
    });
}

void MainWindow::startMultiThreadDownload(qint64 fileSize)
{
    const int threadCnt = ui->t_cnt->value();
    activeTasks.clear();
    downloadedBytes = 0;
    qint64 chunkSize = fileSize / threadCnt;
    
    for (int i = 0; i < threadCnt; ++i) {
        qint64 start = i * chunkSize;
        qint64 end = (i == threadCnt - 1) ? fileSize - 1 : start + chunkSize - 1;
        
        DownloadTask* task = new DownloadTask(downloadUrl, saveDir, fileName, start, end);
        connect(task, &DownloadTask::progress, this, &MainWindow::onDownloadProgress, Qt::QueuedConnection);
        connect(task, &DownloadTask::finished, this, &MainWindow::onDownloadFinished, Qt::QueuedConnection);
        activeTasks.append(task);
        task->start();
    }
}

void MainWindow::onDownloadProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    downloadedBytes += bytesReceived;
    ui->progress->setMaximum(bytesTotal);
    ui->progress->setValue(downloadedBytes);
}

void MainWindow::onDownloadFinished()
{
    if (QObject::sender()) {
        activeTasks.removeAll(static_cast<DownloadTask*>(QObject::sender()));
    }
    if (activeTasks.isEmpty()) {
        ui->progress->setValue(totalBytes);
        QMessageBox::information(this, tr("完成"), tr("下载完成"));
    }
}

void MainWindow::chooseSaveDir()
{
    QString dir = QFileDialog::getExistingDirectory(this, tr("选择目录"), "", QFileDialog::ShowDirsOnly);
    if (!dir.isEmpty()) {
        ui->savepath->setText(dir);
    }
}
