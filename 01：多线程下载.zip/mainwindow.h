#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QFile>
#include <QPushButton>
#include <QProgressBar>
#include <QThread>
#include <QMessageBox>
#include <QFileDialog>
#include "downloadtask.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

// 前向声明自定义线程类（需单独实现）
class DownloadTask;

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    Ui::MainWindow *ui;
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // UI按钮点击触发下载
    void onStartDownloadClicked();

    // 线程进度更新
    void onDownloadProgress(qint64 bytesReceived, qint64 bytesTotal);

    // 线程完成处理
    void onDownloadFinished();

    void chooseSaveDir();


private:


    // 下载相关
    QNetworkAccessManager *manager;
    QFile *outputFile;
    QUrl downloadUrl;
    QString savePath;
    QString saveDir;
    QString fileName;
    qint64 totalBytes;
    qint64 downloadedBytes;
    QList<DownloadTask*> activeTasks;
    int activeTaskCount;

    // 工具方法
    void setupUi();
    void startMultiThreadDownload(qint64 fileSize);
    void mergeTempFiles();

};

#endif // MAINWINDOW_H
